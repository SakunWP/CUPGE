void affiche(int * ch){

}




int main(){
    Liste DC=dc();
    //ajouter(4,DC);
    //trouver(4,DC);
    //supprimer(4,DC);
    //printf("lol1");
    int ln[7] = {83, 79, 71, 78, 65, 84, 83};
    for(int i=0; i<7;i++){
        ajouter(ln[i],DC);
    }
    trouver(83,DC);
    //supprimer(83,DC);   //segmentation erreur associé à supprimer!!
    alenvers(DC);
    return 0;

}